export const CONTRACT_SPAN_DAYS = 15;
export const TODAY = new Date();
